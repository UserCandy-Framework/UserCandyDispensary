Credits
--
Thank You to all who helped make UserCandy possible.  
The following contributed to the UC build.  
If your name is not on the list, please let us know so that we can add it.  
--
David (DaVaR) Sargent – https://www.usercandy.com/
Gary Mathis - https://www.youtube.com/channel/UCtDDxnmPWXcTj1GSrkFMqKg
David Carr @ Nova Framework - http://novaframework.com/
Bartek Kuśmierczuk - contact@qsma.pl - http://qsma.pl
Jhobanny Morillo - geomorillo@yahoo.com
Bryan Yeh
Cam Tosh
EddyBeaupre
Bootswatch Themes - https://www.bootswatch.com
Lightbox - https://lokeshdhakar.com/projects/lightbox2/
