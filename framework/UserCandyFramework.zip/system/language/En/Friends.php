<?php
/**
* Language File
* Friends
* English Language
*
* UserCandy
* @author David (DaVaR) Sargent <davar@usercandy.com>
* @version 1.0.0
*/

return [
	/** Friends **/
	'friends_username' => "User Name",
	'send_friend_request' => "Send Friend Request",
	'friend' => "Friend",
	'your_friend' => "Your Friend",
	'pending_approval' => "Pending Approval",
	'search_found' => "Search Found",
	'matches_for' => "Matches For",
	'search' => "Search",
	'search_friends' => "Search Friends",
];
